const steps = document.querySelectorAll(".step");
const indicators = document.querySelectorAll(".step-indicator");
const nextBtn = document.getElementById("nextBtn");
const backBtn = document.getElementById("backBtn");
const plans = document.querySelectorAll(".plan");
const addons = document.querySelectorAll(".addon");
const toggle = document.getElementById("billingToggle");

let currentStep = 0;
let yearly = false;
let selectedPlan = plans[0];
let selectedAddons = [];

function updateUI() {
  steps.forEach((step, i) => {
    step.classList.toggle("active", i === currentStep);
    if (indicators[i]) {
      indicators[i].classList.toggle("active", i === currentStep);
    }
  });

  backBtn.style.display = currentStep === 0 || currentStep === 4 ? "none" : "inline-block";
  nextBtn.textContent = currentStep === 3 ? "Confirm" : "Next Step";
}

nextBtn.onclick = () => {
  if (currentStep === 3) {
    currentStep = 4; // THANK YOU
    updateUI();
    nextBtn.style.display = "none";
    backBtn.style.display = "none";
    return;
  }
  currentStep++;
  updateUI();
};

backBtn.onclick = () => {
  currentStep--;
  updateUI();
};

plans.forEach(plan => {
  plan.onclick = () => {
    plans.forEach(p => p.classList.remove("active"));
    plan.classList.add("active");
    selectedPlan = plan;
  };
});

toggle.onchange = () => {
  yearly = toggle.checked;

  plans.forEach(plan => {
    const price = yearly ? plan.dataset.year : plan.dataset.month;
    plan.querySelector(".price").textContent =
      `$${price}/${yearly ? "yr" : "mo"}`;
    plan.querySelector(".free").classList.toggle("hidden", !yearly);
  });

  addons.forEach(addon => {
    const price = yearly ? addon.dataset.year : addon.dataset.month;
    addon.querySelector(".addon-price").textContent =
      `+$${price}/${yearly ? "yr" : "mo"}`;
  });
};

addons.forEach(addon => {
  const checkbox = addon.querySelector("input");
  checkbox.onchange = () => {
    if (checkbox.checked) selectedAddons.push(addon);
    else selectedAddons = selectedAddons.filter(a => a !== addon);
  };
});

function renderSummary() {
  const summary = document.getElementById("summary");
  const total = document.getElementById("total");

  let sum = yearly ? +selectedPlan.dataset.year : +selectedPlan.dataset.month;

  summary.innerHTML = `
    <p><strong>${selectedPlan.dataset.name}</strong> (${yearly ? "Yearly" : "Monthly"})</p>
  `;

  selectedAddons.forEach(addon => {
    const price = yearly ? addon.dataset.year : addon.dataset.month;
    sum += +price;
    summary.innerHTML += `<p>${addon.dataset.name}: +$${price}</p>`;
  });

  total.textContent = `Total: $${sum}/${yearly ? "yr" : "mo"}`;
}

document.addEventListener("click", () => {
  if (currentStep === 3) renderSummary();
});

updateUI();