const steps = document.querySelectorAll(".step");
const indicators = document.querySelectorAll(".step-indicator");
const nextBtn = document.getElementById("nextBtn");
const backBtn = document.getElementById("backBtn");

const plans = document.querySelectorAll(".plan");
const billing = document.getElementById("billing");
const billingLabels = document.querySelectorAll(".billing-label");

let currentStep = 0;
let yearly = false;

function showStep(index) {
  steps.forEach(s => s.classList.remove("active"));
  indicators.forEach(i => i.classList.remove("active"));

  steps[index].classList.add("active");
  indicators[index]?.classList.add("active");

  backBtn.style.display = index === 0 ? "none" : "inline-block";
  nextBtn.textContent = index === 3 ? "Confirm" : "Next Step";
  if (index === 4) nextBtn.style.display = "none";
}

plans.forEach(plan => {
  plan.addEventListener("click", () => {
    plans.forEach(p => p.classList.remove("active"));
    plan.classList.add("active");
  });
});

billing.addEventListener("change", () => {
  yearly = billing.checked;

  billingLabels.forEach(l => l.classList.remove("active"));
  billingLabels[yearly ? 1 : 0].classList.add("active");

  plans.forEach(plan => {
    const price = yearly ? plan.dataset.yearly : plan.dataset.monthly;
    plan.querySelector(".price").textContent =
      yearly ? `$${price}/yr` : `$${price}/mo`;

    plan.classList.toggle("yearly", yearly);
  });
});

nextBtn.onclick = () => {
  if (currentStep < steps.length - 1) {
    currentStep++;
    showStep(currentStep);
  }
};

backBtn.onclick = () => {
  if (currentStep > 0) {
    currentStep--;
    showStep(currentStep);
  }
};

showStep(currentStep);